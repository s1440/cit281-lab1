/*
    CIT 281 Project 1
    Name: Sophie Sheppe
*/

function dayOutput () {
    const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]; const d = new Date(); let day = days[d.getDay()]; console.log(day);
}

dayOutput();
// make that into function then console.log - incorporate into function
// need to the array to do something
// make sure you have the actual function name written out at the bottom so that it runs
